print(len(str(1000)))

print(str(2+2)),print(str(2-2))

numbers = [5, 8, 10, 4, 7]
a = sum(numbers) / len(numbers)
print(a)

a='Понедельник'
b='Вторник'
c= ','
print(a,c,b)

a=1
b=2
c=3
d=(a * b) + (a * c)
f=d**3/2
print(f)